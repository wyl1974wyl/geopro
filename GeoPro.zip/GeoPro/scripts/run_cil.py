"""Runs one CIL experiment (GeoPro or matched frozen-feature baselines).

Usage:
    python scripts/run_cil.py --config configs/cifar100_b0_inc10.yaml --method geopro
    python scripts/run_cil.py --config configs/cifar100_b0_inc10.yaml --method all
"""

import argparse
import os
import sys

import numpy as np
import torch
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from geopro.cil import run_incremental, base_novel_hm
from geopro.data import IncrementalScheduler
from geopro.heads import GeoProHead, SimpleCILHead, FeCAMHead, RanPACHead


def build_head(method: str, cfg: dict):
    device = cfg.get("device", "cuda")
    if method == "geopro":
        g = cfg["geopro"]
        return GeoProHead(eps=g.get("eps", 1e-8), k_max=g.get("k_max", 512), device=device)
    if method == "simplecil":
        return SimpleCILHead(device=device)
    if method == "fecam":
        return FeCAMHead(device=device)
    if method == "ranpac":
        r = cfg.get("ranpac", {})
        return RanPACHead(proj_dim=r.get("proj_dim", 10000),
                          ridge=r.get("ridge", 1.0), device=device)
    raise ValueError(f"unknown method: {method}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--method", default="geopro",
                        choices=["geopro", "simplecil", "fecam", "ranpac", "all"])
    args = parser.parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    cache = cfg["features"]["cache_dir"]
    name = f"{cfg['dataset']['name']}_{cfg['backbone']['name']}"
    train = torch.load(os.path.join(cache, f"{name}_train.pt"))
    test = torch.load(os.path.join(cache, f"{name}_test.pt"))

    methods = ["geopro", "simplecil", "fecam", "ranpac"] if args.method == "all" \
        else [args.method]
    noise = cfg.get("label_noise", 0.0)
    few_shot = cfg.get("few_shot", None)
    seeds = cfg.get("class_order_seeds", [0, 1, 2])

    for method in methods:
        accs = []
        for seed in seeds:
            split = IncrementalScheduler.from_config(cfg["protocol"], seed).build()
            head = build_head(method, cfg)
            result = run_incremental(
                head, split,
                train["features"], train["labels"],
                test["features"], test["labels"],
                few_shot=few_shot, label_noise=noise, seed=seed,
            )
            accs.append(result["avg_inc_acc"])
            if few_shot is not None:
                base_set = set(split.task_classes[0])
                seen = set().union(*split.task_classes)
                mask = np.isin(test["labels"].numpy(), list(seen))
                preds = head.predict(test["features"][mask])
                b, n, hm = base_novel_hm(preds.numpy(),
                                         test["labels"][mask].numpy(), base_set)
                print(f"[{method}][seed {seed}] Base {b:.2f} Novel {n:.2f} HM {hm:.2f}")
            print(f"[{method}][seed {seed}] avg-incremental ACC {result['avg_inc_acc']:.2f}")
        print(f"[{method}] mean over {len(seeds)} orders: "
              f"{np.mean(accs):.2f} +- {np.std(accs):.2f}")


if __name__ == "__main__":
    main()
