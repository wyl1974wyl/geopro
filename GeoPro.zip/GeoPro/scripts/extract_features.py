"""Extracts frozen backbone features once, cached for all head experiments.

Usage:
    python scripts/extract_features.py --config configs/cifar100_b0_inc10.yaml
"""

import argparse
import os
import sys

import torch
import yaml
from torch.utils.data import DataLoader
from tqdm import tqdm

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from geopro.backbones import build_backbone
from geopro.data import build_dataset


@torch.no_grad()
def extract(backbone, loader) -> tuple[torch.Tensor, torch.Tensor]:
    feats, labels = [], []
    for images, targets in tqdm(loader, desc="extracting features"):
        feats.append(backbone(images).cpu())
        labels.append(targets)
    return torch.cat(feats), torch.cat(labels)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    backbone = build_backbone(cfg["backbone"])
    out_dir = cfg["features"]["cache_dir"]
    os.makedirs(out_dir, exist_ok=True)

    for split in ("train", "test"):
        dataset = build_dataset(cfg["dataset"], split)
        loader = DataLoader(dataset, batch_size=cfg["features"].get("batch_size", 256),
                            shuffle=False, num_workers=8, pin_memory=True)
        feats, labels = extract(backbone, loader)
        out_path = os.path.join(
            out_dir, f"{cfg['dataset']['name']}_{cfg['backbone']['name']}_{split}.pt")
        torch.save({"features": feats, "labels": labels}, out_path)
        print(f"saved {split}: {feats.shape} -> {out_path}")


if __name__ == "__main__":
    main()
