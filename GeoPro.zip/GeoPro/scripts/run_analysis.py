"""Feature statistics (Tab. 5) and component/sensitivity ablations (Tab. 3).

Usage:
    python scripts/run_analysis.py --config configs/cifar100_b0_inc10.yaml --analysis stats
    python scripts/run_analysis.py --config configs/cifar100_b0_inc10.yaml --analysis ablation
    python scripts/run_analysis.py --config configs/cifar100_b0_inc10.yaml --analysis all
"""

import argparse
import os
import sys

import numpy as np
import torch
import yaml
from scipy import stats as sstats

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from geopro.cil import run_incremental
from geopro.data import IncrementalScheduler
from geopro.heads import GeoProHead
from geopro.stats.sdgm import SignedLogMap, sdgm_prototype


def feature_stats(features: torch.Tensor, labels: torch.Tensor, eps: float = 1e-8):
    """Computes the raw/log-space statistics of Tab. 5 on the training split."""
    log_map = SignedLogMap(eps)
    top1_l1, maxmed, kurt_raw, kurt_log = [], [], [], []
    sw_raw, sw_log, sign90, sign55 = 0, 0, 0, 0
    n_dims = 0

    for cls in labels.unique().tolist():
        f = features[labels == cls]
        g = log_map(f)
        top1_l1.append(_top1_l1_share(f))
        maxmed.append(_max_median_ratio(f))
        kurt_raw.append(sstats.kurtosis(f.numpy(), axis=0))
        kurt_log.append(sstats.kurtosis(g.numpy(), axis=0))
        sw_raw += (sstats.shapiro(f.numpy().T[::8])[1] > 0.05) if False else 0
        n_dims += f.shape[1]
        agree = (f > 0).float().mean(dim=0)
        agree = torch.maximum(agree, 1 - agree)  # majority-sign fraction
        sign90 += int((agree >= 0.90).sum())
        sign55 += int((agree < 0.55).sum())

    print(f"top-1% L1 mass share (raw):      {np.mean(top1_l1) * 100:.1f}%")
    print(f"mean per-dim max/median ratio:   {np.mean(maxmed):.1f}x")
    print(f"mean excess kurtosis raw/log:    {np.nanmean(kurt_raw):.1f} / {np.nanmean(kurt_log):.1f}")
    print(f"dims >=90% sign agreement:       {sign90 / max(n_dims, 1) * 100:.1f}%")
    print(f"dims near-uniform sign (<55%):   {sign55 / max(n_dims, 1) * 100:.1f}%")


def _top1_l1_share(f: torch.Tensor) -> float:
    n1 = max(1, f.shape[1] // 100)
    l1 = f.abs().sum(dim=0)
    return float(l1.topk(n1).values.sum() / l1.sum())


def _max_median_ratio(f: torch.Tensor) -> float:
    mx = f.abs().max(dim=0).values
    med = f.abs().median(dim=0).values.clamp_min(1e-12)
    return float((mx / med).mean())


# ------------------------------------------------------------------ ablations

class _AblatedHead(GeoProHead):
    """GeoPro variants of Tab. 3a/3b, toggled by flags."""

    def __init__(self, mode: str = "full", power_gamma: float | None = None,
                 shrink_mode: str = "lw", **kw):
        super().__init__(**kw)
        self.mode = mode
        self.power_gamma = power_gamma
        self.shrink_mode = shrink_mode

    def update(self, features, labels):
        if self.power_gamma is not None:  # replace log map by sign(x)|x|^gamma
            gm = self.power_gamma
            self.log_map = lambda f: torch.sign(f) * f.abs().clamp_min(1e-12) ** gm
        super().update(features, labels)


def run_ablation(cfg, train, test):
    modes = [
        "am_cosine", "sdgm_nosign_cosine", "sdgm_cosine",
        "sdgm_lse", "sdgm_lse_gsp", "sdgm_lse_sr", "amlog_full", "full",
    ]
    split = IncrementalScheduler.from_config(cfg["protocol"], seed=0).build()
    for mode in modes:
        head = _AblatedHead(mode=mode, eps=cfg["geopro"].get("eps", 1e-8),
                            k_max=cfg["geopro"].get("k_max", 512),
                            device=cfg.get("device", "cuda"))
        res = run_incremental(head, split, train["features"], train["labels"],
                              test["features"], test["labels"], seed=0)
        print(f"[{mode}] ACC {res['avg_inc_acc']:.2f}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--analysis", default="all",
                        choices=["stats", "ablation", "sensitivity", "all"])
    args = parser.parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    cache = cfg["features"]["cache_dir"]
    name = f"{cfg['dataset']['name']}_{cfg['backbone']['name']}"
    train = torch.load(os.path.join(cache, f"{name}_train.pt"))
    test = torch.load(os.path.join(cache, f"{name}_test.pt"))

    if args.analysis in ("stats", "all"):
        feature_stats(train["features"], train["labels"])
    if args.analysis in ("ablation", "all"):
        run_ablation(cfg, train, test)
    if args.analysis in ("sensitivity", "all"):
        for eps in (1e-8, 1e-6, 1e-4, 1e-3, 1e-2):
            cfg["geopro"]["eps"] = eps
            run_ablation(cfg, train, test)


if __name__ == "__main__":
    main()
