"""Global between-class subspace projection.

From all C class centers nu_c, forms the between-class scatter
    S_B = (1/C) sum_c (nu_c - nu_bar)(nu_c - nu_bar)^T
and retains the top-k eigenvectors V_k in R^{d x k}, with
k = min(C - 1, k_max), k_max = 512 (binding only for C > 513).
Whitening by the within-class scatter S_W is deliberately omitted:
infeasible at few-shot, near-neutral after Ledoit--Wolf shrinkage at full
shot (Sec. 3.4 of the paper).
"""

import torch


def between_class_subspace(
    centers: torch.Tensor, k_max: int = 512
) -> torch.Tensor:
    """Computes the top-k eigenvectors of the between-class scatter.

    Args:
        centers: (C, d) log-space class centers nu_c.
        k_max: hard cap on the retained dimension (default 512).

    Returns:
        V_k: (d, k) projection matrix, k = min(C - 1, k_max).
    """
    C, d = centers.shape
    k = min(C - 1, k_max)
    mean_center = centers.mean(dim=0)
    xc = centers - mean_center
    scatter = (xc.T @ xc) / C
    eigvals, eigvecs = torch.linalg.eigh(scatter)
    # eigh returns ascending eigenvalues; take the top-k
    idx = torch.argsort(eigvals, descending=True)[:k]
    return eigvecs[:, idx]
