"""Signed log-space map and sign-decomposed geometric mean (SDGM) prototype.

Implements Eqs. (1)-(4) of the paper:
    g_i   = sign(f_i) * log(|f_i| + eps)                     (signed log map)
    s_c   = sign( mean_i sign(f_i) )                         (per-dim sign vote)
    m_c   = exp( mean_i log(|f_i| + eps) )                   (geometric mean of magnitudes)
    p_c   = s_c * m_c                                        (SDGM prototype)
Sign ties are broken by the arithmetic mean's sign (Tab. 3b, Tie-breaking row).
"""

import torch


class SignedLogMap:
    """Applies g = sign(f) * log(|f| + eps) element-wise."""

    def __init__(self, eps: float = 1e-8):
        self.eps = eps

    def __call__(self, f: torch.Tensor) -> torch.Tensor:
        return torch.sign(f) * torch.log(torch.abs(f) + self.eps)

    def log_magnitude(self, f: torch.Tensor) -> torch.Tensor:
        """Returns log(|f| + eps), used for covariance-center computation."""
        return torch.log(torch.abs(f) + self.eps)


def sdgm_prototype(
    features: torch.Tensor, eps: float = 1e-8
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Computes the SDGM prototype of one class from its L2-normalized features.

    Args:
        features: (n_c, d) L2-normalized features of a single class.
        eps: stabilizer of the log map (1e-8 throughout the paper).

    Returns:
        proto: (d,) SDGM prototype p_c = s_c * m_c.
        sign_vote: (d,) per-dimension sign vote s_c in {-1, +1}.
        log_mean_mag: (d,) mean of log(|f| + eps), i.e. log(m_c).
    """
    log_mag = torch.log(torch.abs(features) + eps)  # (n_c, d)
    log_mean_mag = log_mag.mean(dim=0)  # (d,)
    mag = torch.exp(log_mean_mag)  # geometric mean of magnitudes

    vote = torch.sign(features).sum(dim=0)  # sum of +/-1 per dim
    sign_vote = torch.sign(vote)
    tie = sign_vote == 0
    if tie.any():  # ties broken by the arithmetic mean's sign
        am_sign = torch.sign(features.mean(dim=0))
        sign_vote[tie] = torch.where(
            am_sign[tie] >= 0, torch.ones_like(sign_vote[tie]), -torch.ones_like(sign_vote[tie])
        )

    proto = sign_vote * mag
    return proto, sign_vote, log_mean_mag


def log_space_center(sign_vote: torch.Tensor, log_mean_mag: torch.Tensor) -> torch.Tensor:
    """Log-space image of the SDGM center: nu_c = s_c * (1/n_c) sum_i log(|f_i| + eps)."""
    return sign_vote * log_mean_mag
