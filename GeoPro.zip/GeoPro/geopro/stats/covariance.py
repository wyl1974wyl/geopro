"""Log-space covariance estimation and closed-form shrinkage.

Implements Eqs. (6)-(7) of the paper:
    Sigma_c     = (1/n_c) sum_i (g_i - nu_c)(g_i - nu_c)^T      (MLE divisor)
    Sigma_pool  = (1/C) sum_c Sigma_c
    Sigma_c^reg = (1 - a_c) Sigma_c + a_c Sigma_pool^LW
where a_c is the Ledoit--Wolf closed-form intensity evaluated against the
pooled target (an empirical choice, as the LW derivation assumes a
scaled-identity target).
"""

import torch


def estimate_covariances(
    log_features: torch.Tensor, center: torch.Tensor
) -> torch.Tensor:
    """MLE covariance of log-space features of one class around its center.

    Args:
        log_features: (n_c, d) signed log-space features g_i.
        center: (d,) log-space class center nu_c.

    Returns:
        (d, d) MLE covariance; zeros when n_c == 1 (class rests on the
        center and the pooled geometry, cf. Sec. 3.3 of the paper).
    """
    n = log_features.shape[0]
    if n == 1:
        return torch.zeros(
            log_features.shape[1], log_features.shape[1],
            dtype=log_features.dtype, device=log_features.device,
        )
    xc = log_features - center
    return (xc.T @ xc) / n


def ledoit_wolf_shrinkage(
    cov: torch.Tensor, samples: torch.Tensor
) -> tuple[torch.Tensor, float]:
    """Ledoit--Wolf-shrunk covariance with closed-form intensity.

    Args:
        cov: (d, d) sample covariance (MLE).
        samples: (n, d) samples used to estimate `cov`.

    Returns:
        shrunk covariance, intensity in [0, 1].
    """
    n, d = samples.shape
    mu = torch.diagonal(cov).mean()
    target = mu * torch.eye(d, dtype=cov.dtype, device=cov.device)

    delta2 = ((cov - target) ** 2).sum() / d  # squared distance to target
    centered = samples - samples.mean(dim=0)
    # estimation variance of the sample covariance entries
    beta_sum = 0.0
    for i in range(n):
        outer = torch.outer(centered[i], centered[i]) - cov
        beta_sum = beta_sum + (outer ** 2).sum()
    beta2 = beta_sum / (n * n * d)
    intensity = float(torch.clamp(beta2 / (delta2 + 1e-12), 0.0, 1.0))

    shrunk = (1.0 - intensity) * cov + intensity * target
    return shrunk, intensity


def shrink_to_pooled_target(
    class_covs: torch.Tensor,
    class_log_samples: list[torch.Tensor],
) -> torch.Tensor:
    """Shrinks each class covariance towards the LW-shrunk pooled covariance.

    Args:
        class_covs: (C, d, d) per-class MLE covariances.
        class_log_samples: list of (n_c, d) log-space samples per class.

    Returns:
        (C, d, d) regularized covariances Sigma_c^reg.
    """
    pooled = class_covs.mean(dim=0)
    pooled_samples = torch.cat(class_log_samples, dim=0)
    pooled_lw, _ = ledoit_wolf_shrinkage(pooled, pooled_samples)

    reg = torch.empty_like(class_covs)
    for c in range(class_covs.shape[0]):
        _, alpha_c = ledoit_wolf_shrinkage_to_target(
            class_covs[c], class_log_samples[c], pooled_lw
        )
        reg[c] = (1.0 - alpha_c) * class_covs[c] + alpha_c * pooled_lw
    return reg


def ledoit_wolf_shrinkage_to_target(
    cov: torch.Tensor, samples: torch.Tensor, target: torch.Tensor
) -> tuple[torch.Tensor, float]:
    """Closed-form intensity from the ratio between summed estimation variance
    of Sigma_c's entries and their summed squared distance to the target."""
    n, d = samples.shape
    delta2 = ((cov - target) ** 2).sum() / d
    centered = samples - samples.mean(dim=0)
    beta_sum = 0.0
    for i in range(n):
        outer = torch.outer(centered[i], centered[i]) - cov
        beta_sum = beta_sum + (outer ** 2).sum()
    beta2 = beta_sum / (n * n * d)
    alpha = float(torch.clamp(beta2 / (delta2 + 1e-12), 0.0, 1.0))
    return (1.0 - alpha) * cov + alpha * target, alpha
