"""Frozen-feature baseline heads re-run on identical features (matched controls).

Implements the three training-free controls of the paper's same-backbone
comparisons: SimpleCIL (AM nearest class mean), FeCAM (full-covariance
Gaussian head; the diagonal re-implementation is only used as a lower-bound
reference), and RanPAC (fixed random projection + ridge regression).
"""

import torch
import torch.nn.functional as F


class SimpleCILHead:
    """Nearest class mean with arithmetic-mean prototypes (cosine metric)."""

    def __init__(self, device: str = "cpu"):
        self.device = torch.device(device)
        self.classes: list[int] = []
        self.prototypes: list[torch.Tensor] = []

    def update(self, features: torch.Tensor, labels: torch.Tensor) -> None:
        features, labels = features.to(self.device), labels.to(self.device)
        for cls in labels.unique().tolist():
            self.classes.append(int(cls))
            self.prototypes.append(features[labels == cls].mean(dim=0))

    @torch.no_grad()
    def predict(self, features: torch.Tensor) -> torch.Tensor:
        protos = F.normalize(torch.stack(self.prototypes), p=2, dim=-1)
        sims = F.normalize(features.to(self.device), p=2, dim=-1) @ protos.T
        idx = sims.argmax(dim=1)
        return torch.tensor(self.classes, device=self.device)[idx].cpu()


class FeCAMHead:
    """Full-covariance FeCAM: class means + shrunk full covariances, Mahalanobis."""

    def __init__(self, shrink: float = 0.1, device: str = "cpu"):
        self.shrink = shrink
        self.device = torch.device(device)
        self.classes: list[int] = []
        self.means: dict[int, torch.Tensor] = {}
        self.covs: dict[int, torch.Tensor] = {}

    def update(self, features: torch.Tensor, labels: torch.Tensor) -> None:
        features, labels = features.to(self.device), labels.to(self.device)
        for cls in labels.unique().tolist():
            cls = int(cls)
            feats_c = features[labels == cls]
            mean_c = feats_c.mean(dim=0)
            xc = feats_c - mean_c
            n = feats_c.shape[0]
            cov_c = (xc.T @ xc) / max(n, 1)
            d = cov_c.shape[0]
            # covariance shrinkage towards a scaled-identity target
            target = torch.diagonal(cov_c).mean() * torch.eye(d, device=self.device)
            self.classes.append(cls)
            self.means[cls] = mean_c
            self.covs[cls] = (1.0 - self.shrink) * cov_c + self.shrink * target

    @torch.no_grad()
    def predict(self, features: torch.Tensor) -> torch.Tensor:
        feats = features.to(self.device)
        means = torch.stack([self.means[c] for c in self.classes])
        covs = torch.stack([self.covs[c] for c in self.classes])
        d = covs.shape[-1]
        jitter = 1e-6 * torch.eye(d, device=self.device).unsqueeze(0)
        precs = torch.linalg.inv(covs + jitter)
        diff = feats.unsqueeze(1) - means.unsqueeze(0)  # (N, C, d)
        dists = torch.einsum("nck,ckl,ncl->nc", diff, precs, diff)
        idx = dists.argmin(dim=1)
        return torch.tensor(self.classes, device=self.device)[idx].cpu()


class RanPACHead:
    """RanPAC: fixed random projection + Gram accumulation + ridge classifier."""

    def __init__(self, proj_dim: int = 10000, ridge: float = 1.0,
                 seed: int = 0, device: str = "cpu"):
        self.device = torch.device(device)
        self.proj_dim = proj_dim
        self.ridge = ridge
        self.seed = seed
        self.projection: torch.Tensor | None = None
        self.gram: torch.Tensor | None = None  # (M, M)
        self.cross: torch.Tensor | None = None  # (M, num_targets)
        self.classes: list[int] = []

    def _init_projection(self, feat_dim: int) -> None:
        gen = torch.Generator().manual_seed(self.seed)
        w = torch.randn(feat_dim, self.proj_dim, generator=gen)
        self.projection = (w / (feat_dim ** 0.5)).to(self.device)
        self.gram = torch.zeros(self.proj_dim, self.proj_dim, device=self.device)
        self.cross = None

    def update(self, features: torch.Tensor, labels: torch.Tensor) -> None:
        features, labels = features.to(self.device), labels.to(self.device)
        if self.projection is None:
            self._init_projection(features.shape[1])
        z = F.relu(features @ self.projection)  # (N, M)
        new_classes = [int(c) for c in labels.unique().tolist()]
        self.classes.extend(new_classes)
        num_targets = len(self.classes)
        targets = torch.zeros(labels.shape[0], num_targets, device=self.device)
        col = {c: i for i, c in enumerate(self.classes)}
        for i, lab in enumerate(labels.tolist()):
            targets[i, col[int(lab)]] = 1.0
        self.gram += z.T @ z
        if self.cross is None:
            self.cross = z.T @ targets
        else:
            pad = torch.zeros(self.cross.shape[0], num_targets - self.cross.shape[1],
                              device=self.device)
            self.cross = torch.cat([self.cross, pad], dim=1)
            self.cross += z.T @ targets

    @torch.no_grad()
    def predict(self, features: torch.Tensor) -> torch.Tensor:
        feats = features.to(self.device)
        z = F.relu(feats @ self.projection)
        ridge = self.ridge * torch.eye(self.proj_dim, device=self.device)
        weights = torch.linalg.solve(self.gram + ridge, self.cross)
        scores = z @ weights  # (N, num_classes)
        idx = scores.argmax(dim=1)
        return torch.tensor(self.classes, device=self.device)[idx].cpu()


HEAD_REGISTRY = {
    "geopro": None,  # resolved in run_cil (needs eps/k_max from config)
    "simplecil": SimpleCILHead,
    "fecam": FeCAMHead,
    "ranpac": RanPACHead,
}
