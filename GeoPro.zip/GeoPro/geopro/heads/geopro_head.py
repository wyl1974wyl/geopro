"""GeoPro head: SDGM centers, log-space covariances, subspace Mahalanobis.

State persisted between tasks (per class, full-dimensional):
    - sign vote s_c, log-mean magnitude ell_c  -> center nu_c = s_c * ell_c
    - regularized covariance Sigma_c^reg
Because the between-class subspace V_k depends on ALL centers, per-class
statistics are re-projected after every task (Sec. 3.4 of the paper);
the projected cache is inference-time state only. Classification omits the
log-determinant term of the full Gaussian discriminant (Eq. 8).
"""

import torch

from ..stats.sdgm import SignedLogMap, sdgm_prototype, log_space_center
from ..stats.covariance import estimate_covariances, shrink_to_pooled_target
from ..stats.subspace import between_class_subspace


class GeoProHead:
    """Fully training-free incremental head; every update is closed-form."""

    def __init__(self, eps: float = 1e-8, k_max: int = 512, device: str = "cpu"):
        self.eps = eps
        self.k_max = k_max
        self.device = torch.device(device)
        self.log_map = SignedLogMap(eps)

        # persistent full-dimensional per-class statistics
        self.classes: list[int] = []
        self.sign_votes: dict[int, torch.Tensor] = {}
        self.log_centers: dict[int, torch.Tensor] = {}
        self.covariances: dict[int, torch.Tensor] = {}
        self.log_samples: dict[int, torch.Tensor] = {}

        # inference-time projected cache (rebuilt after each task)
        self.projection: torch.Tensor | None = None  # V_k, (d, k)
        self.proj_centers: torch.Tensor | None = None  # (C, k)
        self.proj_precisions: torch.Tensor | None = None  # (C, k, k), cached

    # ------------------------------------------------------------------ fit
    def update(self, features: torch.Tensor, labels: torch.Tensor) -> None:
        """Absorbs one task's training features (L2-normalized, raw space)."""
        features = features.to(self.device)
        labels = labels.to(self.device)
        for cls in labels.unique().tolist():
            cls = int(cls)
            assert cls not in self.classes, f"class {cls} seen twice"
            feats_c = features[labels == cls]
            proto, sign_vote, log_mean_mag = sdgm_prototype(feats_c, self.eps)
            del proto  # the head works with the center's log-space image
            g_c = self.log_map(feats_c)
            nu_c = log_space_center(sign_vote, log_mean_mag)
            cov_c = estimate_covariances(g_c, nu_c)

            self.classes.append(cls)
            self.sign_votes[cls] = sign_vote
            self.log_centers[cls] = nu_c
            self.covariances[cls] = cov_c
            self.log_samples[cls] = g_c

        self._refit()

    def _refit(self) -> None:
        """Re-shrinks covariances and re-projects all statistics (per task)."""
        C = len(self.classes)
        covs = torch.stack([self.covariances[c] for c in self.classes])
        samples = [self.log_samples[c] for c in self.classes]
        reg = shrink_to_pooled_target(covs, samples)
        for i, c in enumerate(self.classes):
            self.covariances[c] = reg[i]

        centers = torch.stack([self.log_centers[c] for c in self.classes])
        self.projection = between_class_subspace(centers, self.k_max)
        V = self.projection
        self.proj_centers = centers @ V  # (C, k)
        proj_covs = torch.einsum("dk,cdl,dl->ckl", V, reg, V)  # (C, k, k)
        # cached precision factors (Cholesky-based solve at inference)
        jitter = 1e-6 * torch.eye(
            proj_covs.shape[-1], device=proj_covs.device
        ).unsqueeze(0)
        self.proj_precisions = torch.linalg.inv(proj_covs + jitter)

    # -------------------------------------------------------------- predict
    @torch.no_grad()
    def predict(self, features: torch.Tensor, batch_size: int = 1024) -> torch.Tensor:
        """Assigns each test feature the class of minimum Mahalanobis distance."""
        feats = features.to(self.device)
        g = self.log_map(feats)  # signed log map at test time
        g_proj = g @ self.projection  # (N, k)
        preds = []
        for i in range(0, g_proj.shape[0], batch_size):
            x = g_proj[i : i + batch_size]  # (B, k)
            diff = x.unsqueeze(1) - self.proj_centers.unsqueeze(0)  # (B, C, k)
            dists = torch.einsum(
                "bck,ckl,bcl->bc", diff, self.proj_precisions, diff
            )
            idx = dists.argmin(dim=1)
            preds.append(torch.tensor(self.classes, device=self.device)[idx])
        return torch.cat(preds).cpu()
