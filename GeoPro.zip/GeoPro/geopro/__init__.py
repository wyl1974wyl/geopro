"""GeoPro: training-free class-incremental learning via log-space geometric statistics."""

__version__ = "1.0.0"
