"""CIL metrics: average incremental accuracy and few-shot Base/Novel/HM."""

import numpy as np


def average_incremental_accuracy(per_task_acc: list[float]) -> float:
    """Mean of the accuracy on all seen classes after each task (incl. last)."""
    return float(np.mean(per_task_acc))


def base_novel_hm(preds: np.ndarray, labels: np.ndarray,
                  base_classes: set[int]) -> tuple[float, float, float]:
    """Final-session base/novel accuracy and harmonic mean (few-shot CIL)."""
    is_base = np.isin(labels, list(base_classes))
    acc_base = float((preds[is_base] == labels[is_base]).mean()) * 100
    acc_novel = float((preds[~is_base] == labels[~is_base]).mean()) * 100
    hm = 2 * acc_base * acc_novel / (acc_base + acc_novel + 1e-12)
    return acc_base, acc_novel, hm
