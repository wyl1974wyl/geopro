"""Incremental evaluation engine shared by all frozen-feature heads.

Consumes pre-extracted frozen features (train/test), replays the task
sequence of a TaskSplit, updates the head after each task, and evaluates on
the union of all classes seen so far without task identity. Optional 30%
symmetric label noise can be injected into each task's training split.
"""

import numpy as np
import torch

from .metrics import average_incremental_accuracy


def run_incremental(
    head,
    task_split,
    train_features: torch.Tensor,
    train_labels: torch.Tensor,
    test_features: torch.Tensor,
    test_labels: torch.Tensor,
    few_shot: int | None = None,
    label_noise: float = 0.0,
    seed: int = 0,
) -> dict:
    """Runs one full incremental session and returns per-task accuracies."""
    from ..data.datasets import sample_few_shot

    num_classes = len(task_split.order)
    rng = np.random.RandomState(seed)
    per_task_acc = []
    seen_classes: set[int] = set()

    for t, classes in enumerate(task_split.task_classes):
        mask = np.isin(train_labels.numpy(), classes)
        feats_t = train_features[mask]
        labels_t = train_labels[mask].clone()

        if few_shot is not None and t > 0:
            feats_t, labels_t = sample_few_shot(feats_t, labels_t, few_shot, seed + t)

        if label_noise > 0:
            n_noisy = int(label_noise * len(labels_t))
            idx = rng.choice(len(labels_t), n_noisy, replace=False)
            for i in idx:
                wrong = rng.randint(0, num_classes - 1)
                if wrong >= labels_t[i].item():
                    wrong += 1
                labels_t[i] = wrong

        head.update(feats_t, labels_t)
        seen_classes.update(classes)

        test_mask = np.isin(test_labels.numpy(), list(seen_classes))
        preds = head.predict(test_features[test_mask])
        acc = float((preds == test_labels[test_mask]).float().mean()) * 100
        per_task_acc.append(acc)

    return {
        "per_task_acc": per_task_acc,
        "avg_inc_acc": average_incremental_accuracy(per_task_acc),
    }
