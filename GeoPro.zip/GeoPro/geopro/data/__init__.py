"""Dataset loaders and incremental task schedulers."""

from .datasets import build_dataset, DATASET_NUM_CLASSES
from .scheduler import IncrementalScheduler

__all__ = ["build_dataset", "DATASET_NUM_CLASSES", "IncrementalScheduler"]
