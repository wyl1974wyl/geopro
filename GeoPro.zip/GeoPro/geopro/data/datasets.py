"""Dataset builders for CIFAR-100, ImageNet-100, ImageNet-R, and CUB-200.

All datasets return images resized/cropped to the backbone's input
resolution; normalization uses the backbone's statistics. ImageNet-100
follows the standard 100-class subset and train/test partition of the
pre-trained-model CIL protocol (Zhou et al.); ImageNet-R uses a fixed-seed
100-class subset; CUB-200 follows the CEC/FACT split.
"""

import json
import os
import random
from pathlib import Path

import torch
from torch.utils.data import Dataset
from torchvision import datasets, transforms
from PIL import Image

DATASET_NUM_CLASSES = {
    "cifar100": 100,
    "imagenet100": 100,
    "imagenet_r": 100,
    "cub200": 200,
}

# standard ImageNet-100 subset (pre-trained-model CIL protocol)
IMAGENET100_CLASSES = list(range(100))  # resolved against the synset file below


def build_transform(image_size: int, train: bool) -> transforms.Compose:
    """Backbone-compatible transforms; no augmentation is ever used for
    the incremental head's statistics."""
    tf = [transforms.Resize(image_size, interpolation=transforms.InterpolationMode.BICUBIC),
          transforms.CenterCrop(image_size),
          transforms.ToTensor(),
          transforms.Normalize(mean=(0.485, 0.456, 0.406),
                               std=(0.229, 0.224, 0.225))]
    return transforms.Compose(tf)


class ImageFolderSubset(Dataset):
    """Generic image-folder dataset restricted to a fixed class subset."""

    def __init__(self, root: str, class_subset: list[int], transform):
        self.base = datasets.ImageFolder(root)
        self.class_subset = sorted(class_subset)
        self.label_map = {orig: new for new, orig in enumerate(self.class_subset)}
        self.indices = [i for i, (_, lab) in enumerate(self.base.samples)
                        if lab in self.label_map]
        self.transform = transform

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        path, lab = self.base.samples[self.indices[idx]]
        img = Image.open(path).convert("RGB")
        return self.transform(img), self.label_map[lab]


def _load_imagenet100_subset(root: str) -> list[int]:
    subset_file = Path(root) / "imagenet100_classes.json"
    with open(subset_file) as f:
        return json.load(f)


def _imagenet_r_subset(root: str, seed: int = 1993) -> list[int]:
    """Fixed-seed 100-class subset of ImageNet-R."""
    base = datasets.ImageFolder(os.path.join(root, "imagenet-r"))
    rng = random.Random(seed)
    return sorted(rng.sample(range(len(base.classes)), 100))


def build_dataset(cfg: dict, split: str) -> Dataset:
    """Builds a dataset from the `dataset` config section.

    cfg keys: name, root, image_size, and for ImageNet-R the fixed `seed`.
    """
    name = cfg["name"]
    root = cfg["root"]
    tf = build_transform(cfg.get("image_size", 224), train=(split == "train"))

    if name == "cifar100":
        return datasets.CIFAR100(root, train=(split == "train"),
                                 download=True, transform=tf)
    if name == "imagenet100":
        subset = _load_imagenet100_subset(root)
        split_dir = os.path.join(root, "train" if split == "train" else "val")
        return ImageFolderSubset(split_dir, subset, tf)
    if name == "imagenet_r":
        # ImageNet-R has no train split; the 100-class subset is used for
        # both incremental fitting and evaluation under distribution shift.
        subset = _imagenet_r_subset(root, cfg.get("seed", 1993))
        return ImageFolderSubset(os.path.join(root, "imagenet-r"), subset, tf)
    if name == "cub200":
        split_dir = os.path.join(root, "train" if split == "train" else "test")
        return ImageFolderSubset(split_dir, list(range(200)), tf)
    raise ValueError(f"unknown dataset: {name}")


def sample_few_shot(features: torch.Tensor, labels: torch.Tensor,
                    shots: int, seed: int = 0) -> tuple[torch.Tensor, torch.Tensor]:
    """Per-class few-shot subsampling for the CEC/FACT protocol."""
    rng = torch.Generator().manual_seed(seed)
    keep_feats, keep_labels = [], []
    for cls in labels.unique().tolist():
        idx = (labels == cls).nonzero(as_tuple=True)[0]
        perm = idx[torch.randperm(len(idx), generator=rng)[:shots]]
        keep_feats.append(features[perm])
        keep_labels.append(labels[perm])
    return torch.cat(keep_feats), torch.cat(keep_labels)
