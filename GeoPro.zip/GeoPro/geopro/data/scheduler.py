"""Incremental task scheduler: class orders and B0-Inc10 / B50-Inc10 splits.

A class order is a permutation of all dataset classes (seeded). B{x}-Inc{m}
means the first (base) task carries x classes and every subsequent task
carries m classes. Results are averaged over three class orders (seeds).
"""

import random
from dataclasses import dataclass


@dataclass
class TaskSplit:
    """One CIL configuration: class order plus per-task class sets."""
    order: list[int]
    task_classes: list[list[int]]  # disjoint per task; union = all classes


class IncrementalScheduler:
    """Builds task splits for a dataset/protocol/seed combination."""

    def __init__(self, num_classes: int, base_classes: int, inc_classes: int,
                 seed: int = 0):
        self.num_classes = num_classes
        self.base_classes = base_classes
        self.inc_classes = inc_classes
        self.seed = seed

    def build(self) -> TaskSplit:
        order = list(range(self.num_classes))
        random.Random(self.seed).shuffle(order)
        tasks = [order[: self.base_classes]]
        rest = order[self.base_classes :]
        for i in range(0, len(rest), self.inc_classes):
            tasks.append(rest[i : i + self.inc_classes])
        return TaskSplit(order=order, task_classes=tasks)

    @staticmethod
    def from_config(cfg: dict, seed: int) -> "IncrementalScheduler":
        return IncrementalScheduler(
            num_classes=cfg["num_classes"],
            base_classes=cfg["base_classes"],
            inc_classes=cfg["increment_classes"],
            seed=seed,
        )
