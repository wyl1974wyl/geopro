"""Frozen backbone registry and expected checkpoint locations.

Pre-trained backbone weights are intentionally NOT included in this
repository. They will be released upon acceptance of the paper. Until
then, place your own checkpoints under:

    checkpoints/
        dinov3_vitb16.pth   # DINOv3-ViT-B/16 backbone weights
        dinov2_vitb14.pth   # DINOv2 ViT-B backbone weights (cross-backbone control)
        clip_vitb16.pt      # OpenAI CLIP ViT-B/16 weights (cross-backbone control)

and pass the corresponding path via the config field `backbone.checkpoint`.
"""

from .extractor import FrozenBackbone, build_backbone

__all__ = ["FrozenBackbone", "build_backbone"]
