"""Frozen backbone wrapper: loads a pre-trained ViT, yields L2-normalized [CLS] features.

The backbone is used strictly as a fixed feature extractor: parameters are
frozen, dropout is disabled, and no gradient is ever computed through it.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

_BACKBONE_DIMS = {
    "dinov3_vitb16": 768,
    "dinov2_vitb14": 768,
    "clip_vitb16": 512,
}


class FrozenBackbone(nn.Module):
    """Wraps a pre-trained ViT as a frozen [CLS] feature extractor."""

    def __init__(self, name: str, checkpoint: str, device: str = "cuda"):
        super().__init__()
        self.name = name
        self.embed_dim = _BACKBONE_DIMS[name]
        self.model = self._load_model(name, checkpoint)
        self.model.eval()
        self.model.requires_grad_(False)
        self.device = torch.device(device)
        self.model.to(self.device)

    @staticmethod
    def _load_model(name: str, checkpoint: str) -> nn.Module:
        # NOTE: pre-trained weights are withheld until paper acceptance.
        # Point `checkpoint` at your own DINOv3 / DINOv2 / CLIP ViT-B/16
        # weights (see geopro/backbones/__init__.py).
        raise FileNotFoundError(
            f"Checkpoint for backbone '{name}' not provided: '{checkpoint}'. "
            "Pre-trained backbone weights will be released upon acceptance "
            "of the paper; place your own checkpoint under checkpoints/ and "
            "set `backbone.checkpoint` in the config."
        )

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Returns L2-normalized [CLS] features f_hat = E(x) / ||E(x)||_2."""
        x = x.to(self.device, non_blocking=True)
        feat = self._cls_token(x)
        return F.normalize(feat, p=2, dim=-1)

    def _cls_token(self, x: torch.Tensor) -> torch.Tensor:
        out = self.model(x)
        if isinstance(out, dict):  # DINOv2/DINOv3 style outputs
            out = out.get("x_norm_clstoken", out.get("pooler_output", None))
        if out is None:
            raise RuntimeError(f"Cannot locate [CLS] token in {self.name} output.")
        return out


def build_backbone(cfg: dict) -> FrozenBackbone:
    """Builds a FrozenBackbone from the `backbone` section of a config."""
    return FrozenBackbone(
        name=cfg["name"],
        checkpoint=cfg.get("checkpoint", ""),
        device=cfg.get("device", "cuda"),
    )
